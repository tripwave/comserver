package edu.mit.star.flv.impl;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;

import edu.mit.star.flv.Capture;

public class Capturer implements Capture
{
	FLVStream worker;
	Dimension size;

	public Capturer(OutputStream os, Dimension caputreSize) throws IOException
	{
		if (caputreSize.width % 16 != 0 || caputreSize.height % 16 != 0)
		{
			throw new RuntimeException("size needs to be dividibe with 16");
		}
		worker = new FLVStream(os, FLVStream.VIDEO);
		size = caputreSize;
	}

	public BufferedImage newFrame()
	{
		return new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);
	}

	public void writeFrame(BufferedImage image, int timestamp) throws IOException
	{
		worker.writeImage(image, timestamp);
	}
}
